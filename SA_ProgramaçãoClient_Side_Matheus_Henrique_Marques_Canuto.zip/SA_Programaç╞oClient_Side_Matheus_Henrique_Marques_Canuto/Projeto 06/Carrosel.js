var interval = 0;
/*Query selector all retorna um array o legth retorna a quantidade de imagens*/

var maxSlider = document.querySelectorAll('.box-image').length - 1;

console.log(maxSlider);

sumir();

function sumir(){
    let img = document.querySelectorAll('.box-image img')
    img[1].style.display = 'none';  
    img[2].style.display = 'none';  
    img[3].style.display = 'none';  
    img[4].style.display = 'none';  
}

acao();


function acao() {

    let img = document.querySelectorAll('.box-image img');

    setInterval(() => {
        img[interval].style.display = 'none';
        interval++;

        if (interval > maxSlider) {
            interval = 0;
        }
        img[interval].style.display = 'block';
    }, 3000);
}